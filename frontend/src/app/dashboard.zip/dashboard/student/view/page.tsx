import App from "../components/MyScheduleSection";

export default function Page() {
    return <App />
}