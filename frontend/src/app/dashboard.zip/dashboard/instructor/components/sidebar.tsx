/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import {
  ScrollArea,
  Text,
  Group,
  Box,
  Badge,
  Avatar,
} from "@mantine/core";
import {
  HomeIcon,
  CalendarDaysIcon,
  ChatBubbleLeftRightIcon,
  BellIcon,
  QuestionMarkCircleIcon,
} from "@heroicons/react/24/outline";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

import { Found } from "@/app/auth/auth";

import { useAppDispatch, useAppSelector } from "@/hooks/redux";
import { setActiveSection } from "@/store/slices/uiSlice";

export const InstSidebar = () => {
  const dispatch = useAppDispatch();
  const { activeSection } = useAppSelector((state) => state.ui);
 const [user, setUser] = useState<any>(null);
  
  const router = useRouter();
  
  const handleSetActiveSection = (section: string) => {
    dispatch(setActiveSection(section));
  };


   useEffect(() => {
      const checkAuth = async () => {
        const foundUser = await Found();
        setUser(foundUser);
      };
      checkAuth();
    }, []);

  // Mock department data
  const departmentInfo = {
    name: user?.department_name,
    code: user?.department_name.charAt(0),
    head: user?.full_name,
  };

  useEffect(() => {
    switch (activeSection) {
      case "dashboard":
        router.push("/dashboard/instructor/dashboard");
        break;
      case "myschedule":
        router.push("/dashboard/instructor/view");
        break;
      case "announcements":
        router.push("/dashboard/instructor/announcement");
        break;
      case "SubmitFeedback":
        router.push("/dashboard/instructor/feedback");
        break;
    
      case "helpSupport":
        router.push("/dashboard/instructor/help");
        break;
      default:
        break;
    }
  }, [activeSection, router]);

 

  const renderMenuItem = (key: string, Icon: any, label: string) => {
    const isActive = activeSection === key;
    
    return (
      <button
        key={key}
        onClick={() => handleSetActiveSection(key)}
        className={`w-full flex items-center justify-between p-3 rounded-xl transition-all duration-300 group ${
          isActive
            ? "bg-gradient-to-r from-blue-600 to-blue-600 text-white shadow-lg shadow-blue-500/25"
            : "text-gray-700 hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 hover:text-blue-700 hover:shadow-md"
        }`}
      >
        <Group gap="xs">
          <div className={`p-0 rounded-lg ${
            isActive 
              ? "bg-white/20" 
              : "bg-blue-50 group-hover:bg-blue-100"
          }`}>
            <Icon className={`h-5 w-5 ${
              isActive ? 'text-white' : 'text-blue-600 group-hover:text-blue-700'
            }`} />
          </div>
          <span className="font-semibold text-sm">{label}</span>
        </Group>
      </button>
    );
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-b from-white to-gray-50/50 border-r border-gray-100">
      {/* Department Header */}
      <Box className="p-1 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-indigo-50">
        <Group className="mb-4">
          <Avatar 
            size="lg" 
            color="blue" 
            radius="xl"
            className="border-4 border-white shadow-lg"
          >
            {departmentInfo.code}
          </Avatar>
          <div className="flex-1">
            <Text fw={700} size="lg" className="text-gray-900">
              {departmentInfo.name}
            </Text>
            <Text size="sm" c="dimmed" className="mt-1">
              {departmentInfo.head}
            </Text>
          </div>
        </Group>
        
      </Box>

      {/* Navigation Links */}
      <ScrollArea className="flex-1 px-4 py-6">
        <div className="space-y-2">
          {/* Dashboard */}
          {renderMenuItem("dashboard", HomeIcon, "Dashboard")}

          {/* Instructors */}
          {renderMenuItem("myschedule", CalendarDaysIcon, "My Teaching Schedule")}

          {renderMenuItem("announcements", BellIcon, "Announcements")}
          {renderMenuItem("SubmitFeedback", ChatBubbleLeftRightIcon, "Submit Feedback")}
          {renderMenuItem("helpSupport", QuestionMarkCircleIcon, "Help & Support")}
        </div>

        {/* Quick Actions Footer */}
        <Box className="mt-8 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-100">
          <Text fw={600} size="sm" className="text-green-800 mb-2">
            Quick Actions
          </Text>
          <Group gap="xs">
            <Badge color="green" variant="light" size="sm">
              New Semester
            </Badge>
            <Badge color="blue" variant="light" size="sm">
              Reports Due
            </Badge>
            <Badge color="orange" variant="light" size="sm">
              Meetings
            </Badge>
          </Group>
        </Box>
      </ScrollArea>
    </div>
  );
};
