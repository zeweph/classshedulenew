import SubmitFeedbackSection from "../components/SubmitFeedbackSection"

export default function Page() {
    return <SubmitFeedbackSection />
}