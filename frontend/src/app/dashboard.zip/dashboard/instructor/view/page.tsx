import InstructorScheduleView from "../components/MyCoursesSection";

export default function Page() {
    return <InstructorScheduleView />
}