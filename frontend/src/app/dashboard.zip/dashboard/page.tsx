import DashboardSection from "./department/components/DashboardSection";

export default function Page() {
  return <DashboardSection />
}