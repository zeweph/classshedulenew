import InstructorScheduleView from "../../../components/viewinstructor";

export default function Page() { 
    return <InstructorScheduleView />
}