import BatchSemesterSelector from "../../components/BatchSemesterSelector";

export default function Page() {
    return <BatchSemesterSelector />
}