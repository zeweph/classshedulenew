import ScheduleDashboard from "../components/addschedule";

export default function Page() {
    return <ScheduleDashboard />
}