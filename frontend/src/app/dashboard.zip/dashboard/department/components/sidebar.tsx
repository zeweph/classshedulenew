/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import {
  ScrollArea,
  Text,
  Group,
  Collapse,
  Box,
  Badge,
  Avatar,
} from "@mantine/core";
import {
  BellIcon,
  CalendarDaysIcon,
  ChatBubbleLeftRightIcon,
  HomeIcon,
  UsersIcon,
  ChevronDownIcon,
  PlusIcon,
  EyeIcon,
  MagnifyingGlassIcon,
  ChartBarIcon,
  BookOpenIcon,
  LightBulbIcon,
} from "@heroicons/react/24/outline";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

import { Found } from "@/app/auth/auth";

import { useAppDispatch, useAppSelector } from "@/hooks/redux";
import { setActiveSection } from "@/store/slices/uiSlice";

export const DepSidebar = () => {
  const dispatch = useAppDispatch();
  const { activeSection } = useAppSelector((state) => state.ui);
  const [scheduleMenuOpened, setScheduleMenuOpened] = useState(false);
  const [feedbackMenuOpened, setFeedbackMenuOpened] = useState(false);
    const [user, setUser] = useState<any>(null);
  
  const router = useRouter();
  
  const handleSetActiveSection = (section: string) => {
    dispatch(setActiveSection(section));
  };

  const handleToggleScheduleMenu = () => {
    setScheduleMenuOpened(!scheduleMenuOpened);
  };

  

  const handleToggleFeedbackMenu = () => {
    setFeedbackMenuOpened(!feedbackMenuOpened);
  };
   useEffect(() => {
      const checkAuth = async () => {
        const foundUser = await Found();
        setUser(foundUser);
      };
      checkAuth();
    }, []);

  // Mock department data
  const departmentInfo = {
    name: user?.department_name,
    code: user?.department_name.charAt(0),
    head: user?.full_name,
  };

  const isScheduleActive = activeSection === "addSchedule" || activeSection === "viewSchedule" || activeSection === "manageSchedule" || activeSection === "viewcourse" || activeSection === "View-instructor-Schedule";
  const isFeedbackActive = activeSection === "viewFeedback" || activeSection === "feedbackAnalytic" || activeSection === "feedbackSettings";

  useEffect(() => {
    switch (activeSection) {
      case "dashboard":
        router.push("/dashboard/department/dashboard");
        break;
      case "manageinst":
        router.push("/dashboard/department/manageinstructor");
        break;
      case "addSchedule":
        router.push("/dashboard/department/manageschedule");
        break;
      case "viewSchedule":
        router.push("/dashboard/department/manageschedule/view");
        break;
       case "View-instructor-Schedule":
         router.push("/dashboard/department/manageschedule/view/instructorschedule");
        break;
      case "viewcourse":
         router.push("/dashboard/department/viewCourse");
        break;
      case "announcements":
        router.push("/dashboard/department/announcement");
        break;
      case "viewFeedback":
        router.push("/dashboard/department/feedback");
        break;
      case "feedbackAnalytics":
        router.push("/dashboard/department/feedback/analytics");
        break;
      case "feedbackSettings":
        router.push("/dashboard/department/feedback/settings");
        break;
      case "helpSupport":
        router.push("/dashboard/department/help");
        break;
      default:
        break;
    }
  }, [activeSection, router]);

  const renderSubmenu = (key: string, Icon: any, label: string, submenuItems: any[], isActive: boolean, isOpened: boolean, toggleMenu: () => void) => {
    return (
      <div key={key} className="space-y-1">
        {/* Main Menu Button */}
        <button
          onClick={toggleMenu}
          className={`w-full flex items-center justify-between p-3 rounded-xl transition-all duration-300 group ${
            isActive
              ? "bg-gradient-to-r from-blue-600 to-blue-600 text-white shadow-lg shadow-blue-500/25"
              : "text-gray-700 hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 hover:text-blue-700 hover:shadow-md"
          }`}
        >
          <Group gap="xs">
            <div className={`p-0 rounded-lg ${
              isActive 
                ? "bg-white/20" 
                : "bg-blue-50 group-hover:bg-blue-100"
            }`}>
              <Icon className={`h-5 w-5 ${
                isActive ? 'text-white' : 'text-blue-600 group-hover:text-blue-700'
              }`} />
            </div>
            <span className="font-semibold text-sm">{label}</span>
          </Group>
          <div className="flex items-center gap-2">
             <ChevronDownIcon 
              className={`h-4 w-4 transition-transform duration-300 ${
                isOpened ? 'rotate-180' : ''
              } ${isActive ? 'text-white' : 'text-gray-400 group-hover:text-blue-600'}`} 
            />
          </div>
        </button>

        {/* Submenu Items */}
        <Collapse in={isOpened}>
          <div className="ml-6 space-y-2 border-l-2 border-blue-100 pl-3 py-2">
            {submenuItems.map((item) => (
              <button
                key={item.key}
                onClick={() => handleSetActiveSection(item.key)}
                className={`w-full flex items-center p-3 rounded-lg transition-all duration-200 group ${
                  activeSection === item.key
                    ? "bg-blue-100 text-blue-700 shadow-sm border border-blue-200 transform scale-105"
                    : "text-gray-600 hover:bg-blue-50 hover:text-blue-700 hover:translate-x-1"
                }`}
              >
                <div className={`p-1.5 rounded-md ${
                  activeSection === item.key
                    ? "bg-blue-200"
                    : "bg-gray-100 group-hover:bg-blue-100"
                }`}>
                  <item.icon className="h-4 w-4" />
                </div>
                <span className="font-medium text-sm ml-3">{item.label}</span>
              </button>
            ))}
          </div>
        </Collapse>
      </div>
    );
  };

  const renderMenuItem = (key: string, Icon: any, label: string) => {
    const isActive = activeSection === key;
    
    return (
      <button
        key={key}
        onClick={() => handleSetActiveSection(key)}
        className={`w-full flex items-center justify-between p-3 rounded-xl transition-all duration-300 group ${
          isActive
            ? "bg-gradient-to-r from-blue-600 to-blue-600 text-white shadow-lg shadow-blue-500/25"
            : "text-gray-700 hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 hover:text-blue-700 hover:shadow-md"
        }`}
      >
        <Group gap="xs">
          <div className={`p-0 rounded-lg ${
            isActive 
              ? "bg-white/20" 
              : "bg-blue-50 group-hover:bg-blue-100"
          }`}>
            <Icon className={`h-5 w-5 ${
              isActive ? 'text-white' : 'text-blue-600 group-hover:text-blue-700'
            }`} />
          </div>
          <span className="font-semibold text-sm">{label}</span>
        </Group>
      </button>
    );
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-b from-white to-gray-50/50 border-r border-gray-100">
      {/* Department Header */}
      <Box className="p-1 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-indigo-50">
        <Group className="mb-4">
          <Avatar 
            size="lg" 
            color="blue" 
            radius="xl"
            className="border-4 border-white shadow-lg"
          >
            {departmentInfo.code}
          </Avatar>
          <div className="flex-1">
            <Text fw={700} size="lg" className="text-gray-900">
              {departmentInfo.name}
            </Text>
            <Text size="sm" c="dimmed" className="mt-1">
              {departmentInfo.head}
            </Text>
          </div>
        </Group>
        
      </Box>

      {/* Navigation Links */}
      <ScrollArea className="flex-1 px-4 py-6">
        <div className="space-y-2">
          {/* Dashboard */}
          {renderMenuItem("dashboard", HomeIcon, "Dashboard")}

          {/* Instructors */}
          {renderMenuItem("manageinst", UsersIcon, "Instructors")}

          {/* Schedule Management */}
          {renderSubmenu(
            "manageSchedule", 
            CalendarDaysIcon, 
            "Schedule Management", 
            [
              { key: "addSchedule", icon: PlusIcon, label: "Add New Schedule" },
              { key: "viewSchedule", icon: EyeIcon, label: "View Schedules" },
              { key: "View-instructor-Schedule", icon: MagnifyingGlassIcon, label: "Instructor Search" },
              { key: "viewcourse", icon: BookOpenIcon, label: "Course Overview"},
            ],
            isScheduleActive,
            scheduleMenuOpened,
            handleToggleScheduleMenu,
          )}

             {/* Announcements */}
          {renderMenuItem("announcements", BellIcon, "Announcements")}

          {/* Feedback Dropdown */}
          {renderSubmenu(
            "feedback", 
            ChatBubbleLeftRightIcon, 
            "Feedback & Support", 
            [
              { 
                key: "viewFeedback", 
                icon: EyeIcon, 
                label: "View Feedback", 
                count: 15,
                badgeColor: "green"
              },
              { 
                key: "feedbackAnalytics", 
                icon: ChartBarIcon, 
                label: "Feedback Analytics",
              },
              { 
                key: "helpSupport", 
                icon: LightBulbIcon, 
                label: "Help & Support",
              },
            ],
            isFeedbackActive,
            feedbackMenuOpened,
            handleToggleFeedbackMenu, 
          )}
        </div>

        {/* Quick Actions Footer */}
        <Box className="mt-8 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-100">
          <Text fw={600} size="sm" className="text-green-800 mb-2">
            Quick Actions
          </Text>
          <Group gap="xs">
            <Badge color="green" variant="light" size="sm">
              New Semester
            </Badge>
            <Badge color="blue" variant="light" size="sm">
              Reports Due
            </Badge>
            <Badge color="orange" variant="light" size="sm">
              Meetings
            </Badge>
          </Group>
        </Box>
      </ScrollArea>
    </div>
  );
};
