import ManageInstructor from "../components/ManageInstructor";

export default function Page() {
    return <ManageInstructor />
} 