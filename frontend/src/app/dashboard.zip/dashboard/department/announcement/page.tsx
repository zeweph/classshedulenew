import AnnouncementsSection from "../components/AnnouncementsSection";

export default function PAge() {
    return <AnnouncementsSection />
}