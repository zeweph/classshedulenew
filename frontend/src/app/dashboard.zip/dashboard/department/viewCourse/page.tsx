import ShowCourse from "../components/ShowCourse";

export default function Page() {
    return <ShowCourse />
}