/* eslint-disable @typescript-eslint/no-explicit-any */
// src/app/admin/layout.tsx
"use client";

import React, { useState, useEffect } from "react";
import { AppShell, Burger, Group ,Text,Drawer} from "@mantine/core";
import { useDisclosure } from "@mantine/hooks";
import { IconSun, IconMoon } from "@tabler/icons-react";
import PostHeader from "../../compnent/postHeader";
import { AdminSidebar } from "./admin/components/sidebar"
import { useAppDispatch, useAppSelector } from "@/hooks/redux";
import { setSidebarOpened } from "@/store/slices/uiSlice";
import { Found } from "../auth/auth";
import { DepSidebar } from "./department/components/sidebar";
import { InstSidebar } from "./instructor/components/sidebar";
import { StudSidebar  } from "./student/components/sidebar";

export default function DashLayout({ children }: { children: React.ReactNode }) {
  const [opened, { toggle }] = useDisclosure();
  const [darkMode, setDarkMode] = useState(false);
   const dispatch = useAppDispatch();
  const {  sidebarOpened } = useAppSelector((state) => state.ui);
  const [user, setUser] = useState<any>(null);
       useEffect(() => {
         const checkAuth = async () => {
           const foundUser = await Found();
           setUser(foundUser);
         };
         checkAuth();
       }, []);
  // Initialize theme from localStorage or system preference
  useEffect(() => {
    const initializeTheme = () => {
      try {
        const savedTheme = localStorage.getItem('theme');
        const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        
        if (savedTheme === 'dark' || (!savedTheme && systemPrefersDark)) {
          setDarkMode(true);
          document.documentElement.classList.add('dark');
        } else {
          setDarkMode(false);
          document.documentElement.classList.remove('dark');
        }
      } catch (error) {
        console.error("Error initializing theme:", error);
        // Fallback to light mode
        setDarkMode(false);
        document.documentElement.classList.remove('dark');
      }
    };

    initializeTheme();
  }, []);

  const toggleDarkMode = () => {
    try {
      const newDarkMode = !darkMode;
      setDarkMode(newDarkMode);
      
      if (newDarkMode) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('theme', 'light');
      }
    } catch (error) {
      console.error("Error toggling dark mode:", error);
    }
  };
   const renderSidebar = () => {
        if (user?.role === "admin") {
        return <AdminSidebar />;
      }
      else if (user?.role === "department_head") {
        return <DepSidebar />;
      }
      else if (user?.role === "instructor") {
        return <InstSidebar />;
      }
      else if (user?.role === "student") {
        return <StudSidebar />
      }
    }
  return (
    <AppShell
      header={{ height: 80 }}
      navbar={{
        width: 300,
        breakpoint: 'sm',
        collapsed: { mobile: !opened },
      }}
      padding="md"
      className="bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 transition-colors duration-300"
    >
      <AppShell.Header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700 transition-colors duration-300">
        <Group h="100%" px="md" justify="space-between">
          <Group>
            <Burger
              opened={opened}
              onClick={toggle}
              hiddenFrom="sm"
              size="sm"
              className="dark:text-white transition-colors"
              aria-label="Toggle navigation"
            />
            <PostHeader />
          </Group>
          
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 transition-all duration-200 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
            aria-label="Toggle color scheme"
          >
            {darkMode ? (
              <IconSun size={20} className="text-yellow-500" />
            ) : (
              <IconMoon size={20} className="text-gray-700 dark:text-gray-300" />
            )}
          </button>
        </Group>
      </AppShell.Header>
      <AppShell.Navbar>
       {renderSidebar()}
        <Drawer
                      opened={sidebarOpened}
                      onClose={() => dispatch(setSidebarOpened(false))}
                      padding="md"
                      size="400px"
                      title={
                        <div className="flex items-center justify-between">
                          <Text fw={700} size="lg">Admin Menu</Text>
                        </div>
                      }
                      overlayProps={{ opacity: 0.5, blur: 2 }}
                      zIndex={1000}
                      position="left"
                >
              {renderSidebar()}
            </Drawer>
      </AppShell.Navbar>
        <AppShell.Main c="dimmed" bg={"white"}>
        {children}
      </AppShell.Main>
    </AppShell>
  );
}