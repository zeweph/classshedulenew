import RoomsManager from "../components/RoomsManager";

export default function Page() {
    return <RoomsManager />
}