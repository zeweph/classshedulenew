import ViewFeedbackSection from "../components/ViewFeedbackSection";

export default function Page() {
    return <ViewFeedbackSection />
}