import SemesterManagement from "../components/SemesterManagement";

export default function Page() {
    return <SemesterManagement />
}