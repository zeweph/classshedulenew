import HelpSupportSection from "../components/HelpSupportSection";

export default function page() {
    return <HelpSupportSection />
}