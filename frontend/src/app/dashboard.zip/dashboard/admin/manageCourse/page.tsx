import ManageCourse from "../components/ManageCourse";
export default function  Page () {
return <ManageCourse />
}