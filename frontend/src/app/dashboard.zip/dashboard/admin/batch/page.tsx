import BatchManagementClient from '../components/BatchManagement';

export default function BatchPage() {
  return <BatchManagementClient />;
}