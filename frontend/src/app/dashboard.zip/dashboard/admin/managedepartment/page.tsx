import ManageDepartments from "../components/ManageDeptSection";

export default function Page() {
    return <ManageDepartments />
}