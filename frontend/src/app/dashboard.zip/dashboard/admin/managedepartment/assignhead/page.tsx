import AssignHead from "../../components/AssignHeadModal";
export default function Page() {
    return <AssignHead />
}