/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import React, { useEffect, useState } from "react";
import {
  Container,
  Paper,
  Title,
  Text,
  Button,
  Group,
  LoadingOverlay,
  Box,
  Stack,
  Alert,
  Grid,
  Card,
  Badge,
  TextInput,
  Select,
} from "@mantine/core";
import { useRouter } from "next/navigation";
import {
  IconBooks,
  IconPlus,
  IconRefresh,
  IconAlertCircle,
  IconSearch,
  IconFilter,
} from "@tabler/icons-react";
import { notifications } from "@mantine/notifications";

// Redux imports
import { useAppDispatch, useAppSelector } from "@/hooks/redux";
import { 
  fetchCourses, 
  updateCourse, 
  deleteCourse, 
  setEditingCourse,
  clearError 
} from "@/store/slices/coursesSlice";
import { Authentication, Found } from "@/app/auth/auth";

// Import components
import ViewCourses from "./course/ViewCourses";
import EditCourseModal from "./course/EditCourseModal";
import DeleteCourseModal from "./course/DeleteCourseModal";
const ManageCourse: React.FC = () => {
  const dispatch = useAppDispatch();
  const router = useRouter();
  
  // Redux selectors
  const courses = useAppSelector((state) => state.courses.courses);
  const loading = useAppSelector((state) => state.courses.loading);
  const error = useAppSelector((state) => state.courses.error);
  const editingCourse = useAppSelector((state) => state.courses.editingCourse);
  const submitting = useAppSelector((state) => state.courses.submitting);
  
  // Local state
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  const [deleteModalOpened, setDeleteModalOpened] = useState(false);
  const [editModalOpened, setEditModalOpened] = useState(false);
  const [courseToDelete, setCourseToDelete] = useState<number | null>(null);
  
  // Form state for editing
  const [editForm, setEditForm] = useState({
    course_code: "",
    course_name: "",
    credit_hour: 1,
    category: "",
  });
  
  const categories = ['Major Course', 'Support Course', 'Common Course'];

  // Fetch data on component mount
  useEffect(() => {
    dispatch(fetchCourses());
  }, [dispatch]);

  const [user, setUser] = useState<any>(null);
  useEffect(() => {
    const checkAuth = async () => {
      const foundUser = await Found();
      setUser(foundUser);
    };
    checkAuth();
  }, []);

  // Clear error after 5 seconds
  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => {
        dispatch(clearError());
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [error, dispatch]);

  if (user === null) {
    return <Authentication />;
  }

  // Handle navigation to add course page
  const handleAddCourseClick = () => {
    router.push("/dashboard/admin/managecourse/add");
  };

  // Handle edit course - Open modal
  const handleEditCourse = (course: any) => {
    dispatch(setEditingCourse(course));
    setEditForm({
      course_code: course.course_code,
      course_name: course.course_name,
      credit_hour: course.credit_hour,
      category: course.category,
    });
    setEditModalOpened(true);
  };

  // Handle update course
  const handleUpdateCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCourse) return;

    try {
      await dispatch(updateCourse({
        ...editingCourse,
        course_code: editForm.course_code,
        course_name: editForm.course_name,
        credit_hour: editForm.credit_hour,
        category: editForm.category,
      })).unwrap();

      notifications.show({
        title: "Success!",
        message: "Course updated successfully",
        color: "green",
      });
      
      setEditModalOpened(false);
      dispatch(setEditingCourse(null));
    } catch (error: any) {
      notifications.show({
        title: "Error",
        message: error.message || "Failed to update course",
        color: "red",
      });
    }
  };

  // Handle delete course confirmation
  const handleDeleteConfirm = (courseId: number) => {
    setCourseToDelete(courseId);
    setDeleteModalOpened(true);
  };

  // Handle delete course
  const handleDeleteCourse = async () => {
    if (!courseToDelete) return;

    try {
      await dispatch(deleteCourse(courseToDelete)).unwrap();
      notifications.show({
        title: "Success!",
        message: "Course deleted successfully",
        color: "green",
      });
      setDeleteModalOpened(false);
      setCourseToDelete(null);
    } catch (error: any) {
      notifications.show({
        title: "Error",
        message: error.message || "Failed to delete course",
        color: "red",
      });
    }
  };

  // Cancel editing
  const handleCancelEdit = () => {
    setEditModalOpened(false);
    dispatch(setEditingCourse(null));
    setEditForm({
      course_code: "",
      course_name: "",
      credit_hour: 1,
      category: "",
    });
  };

  // Handle refresh
  const handleRefresh = () => {
    dispatch(fetchCourses());
    notifications.show({
      title: "Refreshed!",
      message: "Course list updated",
      color: "blue",
    });
  };

  // Filter courses based on search term and category
  const filteredCourses = courses.filter(course =>
    (course.course_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    course.course_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    course.category?.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (categoryFilter ? course.category === categoryFilter : true)
  );

  if (loading) {
    return (
      <Container size="xl" py="xl">
        <Card className="min-h-[500px] flex items-center justify-center">
          <LoadingOverlay visible={loading} />
          <div className="text-center">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <Title order={3} c="blue" mb="sm">Loading Courses</Title>
            <Text c="dimmed">Fetching your course catalog...</Text>
          </div>
        </Card>
      </Container>
    );
  }

  return (
    <Container size="xl" py="xl">
      <Stack gap="lg">
        {/* Header Section */}
        <Group justify="space-between">
          <Box>
            <Title order={1} mb="xs">Course Management</Title>
            <Text c="dimmed">Manage and organize your academic course catalog</Text>
          </Box>
          <Group>
            <Badge 
              color="blue" 
              variant="light" 
              size="xl"
            >
              {courses.length} Course{courses.length !== 1 ? 's' : ''}
            </Badge>
            <Button
              leftSection={<IconPlus size={20} />}
              onClick={handleAddCourseClick}
              className="bg-blue-600 hover:bg-blue-700"
              size="md"
            >
              Add Course
            </Button>
          </Group>
        </Group>


        {/* Search and Filters Section */}
        <Card shadow="sm" padding="lg" radius="md" withBorder>
          <Stack gap="md">
            <Group justify="space-between">
              <Text fw={600} size="lg">Search & Filter Courses</Text>
              <Button
                variant="light"
                color="blue"
                leftSection={<IconRefresh size={16} />}
                onClick={handleRefresh}
                size="sm"
              >
                Refresh
              </Button>
            </Group>
            
            <Grid gutter="md">
              <Grid.Col span={{ base: 12, md: 8 }}>
                <TextInput
                  placeholder="Search by course code, name, or category..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  leftSection={<IconSearch size={18} />}
                />
              </Grid.Col>
              <Grid.Col span={{ base: 12, md: 4 }}>
                <Select
                  placeholder="Filter by category"
                  value={categoryFilter}
                  onChange={setCategoryFilter}
                  data={categories.map(cat => ({ value: cat, label: cat }))}
                  clearable
                  leftSection={<IconFilter size={18} />}
                />
              </Grid.Col>
            </Grid>
          </Stack>
        </Card>

        {/* Error Message */}
        {error && (
          <Alert 
            icon={<IconAlertCircle size={24} />} 
            title="Error Loading Courses" 
            color="red" 
            variant="light"
          >
            {error}
          </Alert>
        )}

        {/* Courses Table Component */}
        <ViewCourses
          courses={filteredCourses}
          totalCourses={courses.length}
          onEditClick={handleEditCourse}
          onDeleteClick={handleDeleteConfirm}
          searchTerm={searchTerm}
          categoryFilter={categoryFilter}
        />

        {/* Edit Course Modal */}
        <EditCourseModal
          opened={editModalOpened}
          onClose={handleCancelEdit}
          editingCourse={editingCourse}
          editForm={editForm}
          setEditForm={setEditForm}
          onSubmit={handleUpdateCourse}
          submitting={submitting}
          categories={categories}
        />

        {/* Delete Confirmation Modal */}
        <DeleteCourseModal
          opened={deleteModalOpened}
          onClose={() => {
            setDeleteModalOpened(false);
            setCourseToDelete(null);
          }}
          onConfirm={handleDeleteCourse}
          submitting={submitting}
        />
      </Stack>
    </Container>
  );
};

export default ManageCourse;