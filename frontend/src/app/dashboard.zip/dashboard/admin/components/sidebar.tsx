/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unused-vars */
"use client";

import {
  ScrollArea,
  Text,
  Group,
  Collapse,
  Box,
  Badge,
  Avatar,
  Divider,
} from "@mantine/core";
import {
  AcademicCapIcon,
  BuildingLibraryIcon,
  ChatBubbleLeftRightIcon,
  HomeIcon,
  QuestionMarkCircleIcon,
  UsersIcon,
  ChevronDownIcon,
  PlusIcon,
  BuildingOffice2Icon,
  Cog6ToothIcon,
  UserPlusIcon,
  BuildingStorefrontIcon,
  BuildingOfficeIcon,
  HomeModernIcon,
  ChartBarIcon,
  WrenchScrewdriverIcon,
  EyeIcon,
  UserGroupIcon,
  CalendarIcon,
  DocumentTextIcon,
  LightBulbIcon,
  PhoneIcon,
  DocumentChartBarIcon,
  ShieldCheckIcon,
} from "@heroicons/react/24/outline";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

import { useAppDispatch, useAppSelector } from "@/hooks/redux";
import { setActiveSection } from "@/store/slices/uiSlice";

interface AdminSidebarProps {
  onItemClick?: () => void;
}

export const AdminSidebar = ({ onItemClick }: AdminSidebarProps) => {
  const dispatch = useAppDispatch();
  const { activeSection } = useAppSelector((state) => state.ui);
  const [courseMenuOpened, setCourseMenuOpened] = useState(true);
  const [usersMenuOpened, setUsersMenuOpened] = useState(true);
  const [roomMenuOpened, setRoomMenuOpened] = useState(true);
  const [departmentMenuOpened, setDepartmentMenuOpened] = useState(true);
  const [systemMenuOpened, setSystemMenuOpened] = useState(true);
  const [feedbackMenuOpened, setFeedbackMenuOpened] = useState(true);
  const [batchMenuOpened, setBatchMenuOpened] = useState(true);
  const router = useRouter();

  const handleSetActiveSection = (section: string) => {
    dispatch(setActiveSection(section));
    if (onItemClick) {
      onItemClick();
    }
  };

  const handleToggleCourseMenu = () => {
    setCourseMenuOpened(!courseMenuOpened);
  };

  const handleToggleUsersMenu = () => {
    setUsersMenuOpened(!usersMenuOpened);
  };

  const handleToggleRoomMenu = () => {
    setRoomMenuOpened(!roomMenuOpened);
  };

  const handleToggleDepartmentMenu = () => {
    setDepartmentMenuOpened(!departmentMenuOpened);
  };

  const handleToggleSystemMenu = () => {
    setSystemMenuOpened(!systemMenuOpened);
  };

  const handleToggleFeedbackMenu = () => {
    setFeedbackMenuOpened(!feedbackMenuOpened);
  };

  const handleToggleBatchMenu = () => {
    setBatchMenuOpened(!batchMenuOpened);
  };

  // Mock admin data
  const adminInfo = {
    name: "Administrator",
    role: "System Admin",
    totalUsers: 1247,
    systemStatus: "Online",
  };

  const sidebarLinks = [
    { key: "dashboard", icon: HomeIcon, label: "Dashboard", badge: "updated" },
    { 
      key: "manageUsers", 
      icon: UsersIcon, 
      label: "User Management",
      hasSubmenu: true,
    },
    { 
      key: "manageDepartment", 
      icon: BuildingLibraryIcon, 
      label: "Departments",
      hasSubmenu: true
    },
    { 
      key: "manageCourse", 
      icon: AcademicCapIcon, 
      label: "Course Management",
      hasSubmenu: true 
    },
    { 
      key: "roomManagement", 
      icon: BuildingOffice2Icon, 
      label: "Room Management",
      hasSubmenu: true 
    },
    { 
      key: "batchManagement", 
      icon: CalendarIcon, 
      label: "Batch Management",
      hasSubmenu: true 
    },
    { 
      key: "systemSettings", 
      icon: Cog6ToothIcon, 
      label: "System Settings",
      hasSubmenu: true,
      badge: "admin"
    },
    { 
      key: "feedback", 
      icon: ChatBubbleLeftRightIcon, 
      label: "Feedback & Support",
      hasSubmenu: true,
    },
  ];

  const isCourseActive = activeSection === 'addCourse' || activeSection === 'manageCourse';
  const isUsersActive = activeSection === 'addUser' || activeSection === 'manageUsers';
  const isRoomActive = activeSection === 'blocks' || activeSection === 'floors' || activeSection === 'rooms';
  const isDepartmentActive = activeSection === 'manageDepartments' || activeSection === 'assignHead';
  const isSystemActive = activeSection === 'generalSettings' || activeSection === 'advancedSettings' || activeSection === 'systemReports' || activeSection === 'securitySettings';
  const isFeedbackActive = activeSection === 'viewFeedback' || activeSection === 'feedbackAnalytics' || activeSection === 'helpSupport';
  const isBatchActive = activeSection === 'batch' || activeSection === 'semester';

  const renderSubmenu = (key: string, Icon: any, label: string, submenuItems: any[], isActive: boolean, isOpened: boolean, toggleMenu: () => void, badge?: string, count?: number) => {
    return (
      <div key={key} className="space-y-1">
        {/* Main Menu Button */}
        <button
          onClick={toggleMenu}
          className={`w-full flex items-center justify-between p-3 rounded-xl transition-all duration-300 group ${
            isActive
              ? "bg-gradient-to-r from-blue-600 to-blue-600 text-white shadow-xl shadow-blue-500/25"
              : "text-gray-700 hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 hover:text-blue-700 hover:shadow-md"
          }`}
        >
          <Group gap="xs">
            <div className={`p-0 rounded-lg ${
              isActive 
                ? "bg-white/20" 
                : "bg-blue-50 group-hover:bg-blue-100"
            }`}>
              <Icon className={`h-5 w-5 ${
                isActive ? 'text-white' : 'text-blue-600 group-hover:text-blue-700'
              }`} />
            </div>
            <span className="font-semibold text-sm">{label}</span>
          </Group>
          <div className="flex items-center gap-2">
            {count !== undefined && (
              <Badge 
                size="xs" 
                color={isActive ? "white" : "blue"} 
                variant={isActive ? "outline" : "light"}
              >
                {count}
              </Badge>
            )}
           
            <ChevronDownIcon 
              className={`h-4 w-4 transition-transform duration-300 ${
                isOpened ? 'rotate-180' : ''
              } ${isActive ? 'text-white' : 'text-gray-400 group-hover:text-blue-600'}`} 
            />
          </div>
        </button>

        {/* Submenu Items */}
        <Collapse in={isOpened}>
          <div className="ml-6 space-y-2 border-l-2 border-blue-100 pl-3 py-2">
            {submenuItems.map((item) => (
              <button
                key={item.key}
                onClick={() => handleSetActiveSection(item.key)}
                className={`w-full flex items-center p-3 rounded-lg transition-all duration-200 group ${
                  activeSection === item.key
                    ? "bg-blue-100 text-blue-700 shadow-sm border border-blue-200 transform scale-105"
                    : "text-gray-600 hover:bg-blue-50 hover:text-blue-700 hover:translate-x-1"
                }`}
              >
                <div className={`p-0 rounded-md ${
                  activeSection === item.key
                    ? "bg-blue-200"
                    : "bg-gray-100 group-hover:bg-blue-100"
                }`}>
                  <item.icon className="h-4 w-4" />
                </div>
                <span className="font-medium text-sm ml-3">{item.label}</span>
              </button>
            ))}
          </div>
        </Collapse>
      </div>
    );
  };

  const renderMenuItem = (key: string, Icon: any, label: string, badge?: string, count?: number) => {
    const isActive = activeSection === key;
    
    return (
      <button
        key={key}
        onClick={() => handleSetActiveSection(key)}
        className={`w-full flex items-center justify-between p-3 rounded-lg transition-all duration-300 group ${
          isActive
            ? "bg-gradient-to-r from-blue-600 to-blue-600 text-white shadow-md shadow-blue-500/25"
            : "text-gray-700 hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 hover:text-blue-700 hover:shadow-md"
        }`}
      >
        <Group gap="xs">
          <div className={`p-0 rounded-lg ${
            isActive 
              ? "bg-white/20" 
              : "bg-blue-50 group-hover:bg-blue-100"
          }`}>
            <Icon className={`h-5 w-5 ${
              isActive ? 'text-white' : 'text-blue-600 group-hover:text-blue-700'
            }`} />
          </div>
          <span className="font-semibold text-sm">{label}</span>
        </Group>
      
      </button>
    );
  };

  useEffect(() => {
    switch (activeSection) {
      case "dashboard":
        router.push("/dashboard/admin/dashbaord");
        break;
      case "manageUsers":
        router.push("/dashboard/admin/manageuser");
        break;
      case "addUser":
        router.push("/dashboard/admin/manageuser/add");
        break;
      case "manageCourse":
        router.push("/dashboard/admin/manageCourse");
        break;
      case "addCourse":
        router.push("/dashboard/admin/manageCourse/add");
        break;
      case "manageDepartments":
        router.push("/dashboard/admin/managedepartment");
        break;
      case "assignHead":
        router.push("/dashboard/admin/managedepartment/assignhead");
        break;
      case "blocks":
        router.push("/dashboard/admin/block");
        break;
      case "floors":
        router.push("/dashboard/admin/floor");
        break;
      case "rooms":
        router.push("/dashboard/admin/room");
        break;
      case "batch":
        router.push("/dashboard/admin/batch");
        break;
      case "semester":
        router.push("/dashboard/admin/semester");
        break;
      case "viewFeedback":
        router.push("/dashboard/admin/feedback");
        break;
      case "feedbackAnalytics":
        router.push("/dashboard/admin/feedback/analytics");
        break;
      case "helpSupport":
        router.push("/dashboard/admin/help");
        break;
      case "generalSettings":
        router.push("/dashboard/admin/settings/general");
        break;
      case "advancedSettings":
        router.push("/dashboard/admin/settings/advanced");
        break;
      case "securitySettings":
        router.push("/dashboard/admin/settings/security");
        break;
      case "systemReports":
        router.push("/dashboard/admin/reports");
        break;
      default:
        break;
    }
  }, [activeSection, router]);

  return (
    <div className="flex flex-col h-full bg-gradient-to-b from-white to-gray-50/50 border-r border-gray-100">
      {/* Admin Header */}
      <Box className="p-1 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-indigo-50">
        <Group className="mb-4">
          <Avatar 
            size="lg" 
            color="blue" 
            radius="xl"
            className="border-4 border-white shadow-lg"
          >
            A
          </Avatar>
          <div className="flex-1">
            <Text fw={700} size="lg" className="text-gray-900">
              {adminInfo.name}
            </Text>
            <Text size="sm" c="dimmed" className="mt-1">
              {adminInfo.role}
            </Text>
          </div>
        </Group>
      </Box>

      {/* Navigation Links */}
      <ScrollArea className="flex-1 px-4 py-2">
        <div className="space-y-0">
          {/* Dashboard */}
          {renderMenuItem("dashboard", HomeIcon, "Dashboard", "updated")}

          {/* User Management Dropdown */}
          {renderSubmenu(
            "manageUsers", 
            UsersIcon, 
            "User Management", 
            [
              { key: "addUser", icon: UserPlusIcon, label: "Add New User" },
              { key: "manageUsers", icon: UserGroupIcon, label: "Manage Users", },
            ],
            isUsersActive,
            usersMenuOpened,
            handleToggleUsersMenu,
          )}

          {/* Course Management Dropdown */}
          {renderSubmenu(
            "manageCourse", 
            AcademicCapIcon, 
            "Course Management", 
            [
              { key: "addCourse", icon: PlusIcon, label: "Add New Course" },
              { key: "manageCourse", icon: AcademicCapIcon, label: "Manage Courses",  },
            ],
            isCourseActive,
            courseMenuOpened,
            handleToggleCourseMenu
          )}

          {/* Departments Dropdown */}
          {renderSubmenu(
            "manageDepartment", 
            BuildingLibraryIcon, 
            "Department Management", 
            [
              { key: "manageDepartments", icon: UserGroupIcon, label: "Manage Departments",  },
              { key: "assignHead", icon: UserPlusIcon, label: "Assign Department Head" },
            ],
            isDepartmentActive,
            departmentMenuOpened,
            handleToggleDepartmentMenu,
          )}

          {/* Room Management Dropdown */}
          {renderSubmenu(
            "roomManagement", 
            BuildingOffice2Icon, 
            "Room Management", 
            [
              { key: "blocks", icon: BuildingStorefrontIcon, label: "Manage Blocks" },
              { key: "rooms", icon: HomeModernIcon, label: "Manage Rooms"},
            ],
            isRoomActive,
            roomMenuOpened,
            handleToggleRoomMenu
          )}

          {/* Batch Management Dropdown */}
          {renderSubmenu(
            "batchManagement", 
            CalendarIcon, 
            "Batch Management", 
            [
              { key: "batch", icon: DocumentTextIcon, label: "Manage Batches",   },
              { key: "semester", icon: CalendarIcon, label: "Manage Semesters",   },
            ],
            isBatchActive,
            batchMenuOpened,
            handleToggleBatchMenu
          )}

          <Divider my="sm" />

          {/* System Settings Dropdown */}
          {renderSubmenu(
            "systemSettings", 
            Cog6ToothIcon, 
            "System Settings", 
            [
              { key: "generalSettings", icon: Cog6ToothIcon, label: "General Settings" },
              { key: "securitySettings", icon: ShieldCheckIcon, label: "Security Settings", },
              { key: "advancedSettings", icon: WrenchScrewdriverIcon, label: "Advanced Settings" },
              { key: "systemReports", icon: ChartBarIcon, label: "System Reports",  },
            ],
            isSystemActive,
            systemMenuOpened,
            handleToggleSystemMenu,
            "admin"
          )}

          {/* Feedback & Support Dropdown */}
          {renderSubmenu(
            "feedback", 
            ChatBubbleLeftRightIcon, 
            "Feedback & Support", 
            [
              { 
                key: "viewFeedback", 
                icon: EyeIcon, 
                label: "View Feedback", 
                badgeColor: "green"
              },
              { 
                key: "feedbackAnalytics", 
                icon: DocumentChartBarIcon, 
                label: "Feedback Analytics",
              },
              { 
                key: "helpSupport", 
                icon: LightBulbIcon, 
                label: "Help & Support",
                badgeColor: "blue"
              },
            ],
            isFeedbackActive,
            feedbackMenuOpened,
            handleToggleFeedbackMenu,
            undefined,
            
          )}
        </div>

        {/* System Status Footer */}
        <Box className="mt-8 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-100">
          <Text fw={600} size="sm" className="text-blue-800 mb-2">
            System Status
          </Text>
          <Group gap="xs">
            <Badge color="green" variant="light" size="sm">
              All Systems Online
            </Badge>
            <Badge color="blue" variant="light" size="sm">
              Monitoring
            </Badge>
            <Badge color="orange" variant="light" size="sm">
              Updates Available
            </Badge>
          </Group>
        </Box>
      </ScrollArea>
    </div>
  );
};