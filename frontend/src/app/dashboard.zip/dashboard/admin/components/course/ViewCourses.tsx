/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import React from "react";
import {
  Paper,
  Table,
  Badge,
  Group,
  Text,
  ThemeIcon,
  Button,
  ActionIcon,
  Title
} from "@mantine/core";
import {
  IconEdit,
  IconTrash,
  IconSchool,
  IconCertificate,
  IconPlus
} from "@tabler/icons-react";
import { useRouter } from "next/navigation";


interface ViewCoursesProps {
  courses: any[];
  totalCourses: number;
  onEditClick: (course: any) => void;
  onDeleteClick: (courseId: number) => void;
  searchTerm: string;
  categoryFilter: string | null;
}

const ViewCourses: React.FC<ViewCoursesProps> = ({
  courses,
  totalCourses,
  onEditClick,
  onDeleteClick,
  searchTerm,
  categoryFilter,
}) => {
  const hasActiveFilters = searchTerm || categoryFilter;
    const router = useRouter();
  return (
    <Paper 
      shadow="lg" 
      radius="xl" 
      withBorder 
      className="border-blue-100 overflow-hidden bg-white"
    >
      {courses.length === 0 ? (
        <div className="text-center py-16">
          <ThemeIcon size={80} color="blue" variant="light" className="mb-6 mx-auto" radius="xl">
            <IconSchool size={40} />
          </ThemeIcon>
          <Title order={3} c="dimmed" mb="xs">
            {hasActiveFilters ? "No matching courses found" : "No courses available"}
          </Title>
          <Text c="dimmed" size="md" mb="lg">
            {hasActiveFilters ? "Try adjusting your search or filter criteria" : "Get started by adding your first course"}
          </Text>
          {!hasActiveFilters && (
            <Button 
              leftSection={<IconPlus size={20} />} 
              onClick={() => router.push("/dashboard/admin/managecourse/add")}
              size="lg"
              color="blue"
              radius="xl"
              className="bg-gradient-to-r from-blue-600 to-blue-700 shadow-lg"
            >
              Add First Course
            </Button>
          )}
        </div>
      ) : (
        <>
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4">
            <Group justify="space-between">
              <Text fw={700} size="lg" c="white">
                Course Catalog
              </Text>
              <Badge color="blue" variant="filled" className="text-blue-700">
                {courses.length} of {totalCourses} courses
              </Badge>
            </Group>
          </div>
          
          <div className="overflow-x-auto">
            <Table 
              striped 
              highlightOnHover 
              className="min-w-full"
              classNames={{
                table: "rounded-lg overflow-hidden",
                thead: "bg-blue-50/80",
                th: "text-blue-700 font-bold py-4 text-sm border-b-2 border-blue-200",
                td: "py-4 border-b border-blue-50 transition-colors duration-200",
              }}
            >
              <Table.Thead>
                <Table.Tr>
                  <Table.Th className="text-left pl-8">Course Code</Table.Th>
                  <Table.Th className="text-left">Course Name</Table.Th>
                  <Table.Th className="text-center">Credits</Table.Th>
                  <Table.Th className="text-left">Category</Table.Th>
                  <Table.Th className="text-center pr-8">Actions</Table.Th>
                </Table.Tr>
              </Table.Thead>
              <Table.Tbody>
                {courses.map((course) => (
                  <Table.Tr 
                    key={course.course_id} 
                    className="hover:bg-blue-50/50 group cursor-pointer"
                  >
                    <Table.Td className="pl-8">
                      <Group gap="sm">
                        <ThemeIcon size="sm" color="blue" variant="light" radius="md">
                          <IconCertificate size={14} />
                        </ThemeIcon>
                        <Text fw={600} className="text-blue-700 font-mono text-sm">
                          {course.course_code}
                        </Text>
                      </Group>
                    </Table.Td>
                    <Table.Td>
                      <Text className="text-gray-800 group-hover:text-blue-900 transition-colors">
                        {course.course_name}
                      </Text>
                    </Table.Td>
                    <Table.Td className="text-center">
                      <Badge 
                        color="blue" 
                        variant="light" 
                        size="lg"
                        className="font-semibold"
                      >
                        {course.credit_hour} credit{course.credit_hour !== 1 ? 's' : ''}
                      </Badge>
                    </Table.Td>
                    <Table.Td>
                      <Badge 
                        color={
                          course.category === 'Major Course' ? 'blue' :
                          course.category === 'Support Course' ? 'indigo' : 'violet'
                        }
                        variant="outline" 
                        size="md"
                        className="font-medium"
                      >
                        {course.category}
                      </Badge>
                    </Table.Td>
                    <Table.Td className="pr-8">
                      <Group gap="xs" justify="center">
                        <ActionIcon
                          variant="light"
                          color="blue"
                          size="lg"
                          onClick={() => onEditClick(course)}
                          className="hover:scale-110 transition-all duration-200 hover:bg-blue-100"
                          radius="md"
                        >
                          <IconEdit size={16} />
                        </ActionIcon>
                        <ActionIcon
                          variant="light"
                          color="red"
                          size="lg"
                          onClick={() => onDeleteClick(course.course_id)}
                          className="hover:scale-110 transition-all duration-200 hover:bg-red-100"
                          radius="md"
                        >
                          <IconTrash size={16} />
                        </ActionIcon>
                      </Group>
                    </Table.Td>
                  </Table.Tr>
                ))}
              </Table.Tbody>
            </Table>
          </div>
        </>
      )}
    </Paper>
  );
};

export default ViewCourses;