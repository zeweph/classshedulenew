import BlocksManager from '../components/BlocksManager';

export default function Page() {
  return <BlocksManager />;
}