import AddUserPage from "../../components/user/adduser";

export default function Page() {
    return <AddUserPage />
} 