import ManageUsersPage from "../components/ManageUsersSection";
export default function Page() {
    return <ManageUsersPage />
}